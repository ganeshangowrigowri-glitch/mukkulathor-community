import { useForm, useWatch } from 'react-hook-form'
import Input from '../ui/Input'
import Select from '../ui/Select'
import { BRANCHES, SUB_CLANS_BY_BRANCH, TITLES_BY_BRANCH, GOTHRAMS } from '../../lib/constants'

function toOptions(list) {
  return list.map((v) => ({ value: v, label: v }))
}

export default function Step2Community({ profile, onSubmit, onBack }) {
  const { register, handleSubmit, control, formState: { errors, isSubmitting } } = useForm({
    defaultValues: {
      community: profile.community || 'Mukkulathor',
      branch: profile.branch || '',
      sub_group: profile.sub_group || '',
      title: profile.title || '',
      gothram: profile.gothram || '',
      kula_deivam: profile.kula_deivam || '',
      kula_deivam_place: profile.kula_deivam_place || '',
      kaval_deivam: profile.kaval_deivam || '',
      kaval_deivam_place: profile.kaval_deivam_place || '',
      religion: profile.religion || 'Hindu',
      native_place: profile.native_place || '',
      district: profile.district || '',
      country: profile.country || 'India',
    },
  })

  const selectedBranch = useWatch({ control, name: 'branch' })
  const subClanOptions = selectedBranch ? toOptions(SUB_CLANS_BY_BRANCH[selectedBranch] || []) : []
  const titleOptions = selectedBranch ? toOptions(TITLES_BY_BRANCH[selectedBranch] || []) : []

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
      <div>
        <h2 className="font-display text-lg font-semibold text-navy-900">Community Details</h2>
        <p className="mt-1 text-sm text-slate-500">Your lineage and regional roots within the Mukkulathor community.</p>
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <Input label="Community" required disabled {...register('community')} />
        <Select label="Branch (Kilai)" required options={BRANCHES} placeholder="Select branch" {...register('branch', { required: 'Required' })} error={errors.branch?.message} />

        <Select
          label="Sub-Clan / Pattam"
          options={subClanOptions}
          placeholder={selectedBranch ? 'Select sub-clan' : 'Select a branch first'}
          disabled={!selectedBranch}
          {...register('sub_group')}
        />
        <Select
          label="Title"
          options={titleOptions}
          placeholder={selectedBranch ? 'Select title' : 'Select a branch first'}
          disabled={!selectedBranch}
          {...register('title')}
        />

        <Select label="Gothram" options={toOptions(GOTHRAMS)} placeholder="Select gothram" {...register('gothram')} />
        <div />

        <Input label="Kula Deivam (Family Deity)" {...register('kula_deivam')} />
        <Input label="Kula Deivam Temple / Place" {...register('kula_deivam_place')} />

        <Input label="Kaval Deivam (Guardian Deity)" {...register('kaval_deivam')} />
        <Input label="Kaval Deivam Temple / Place" {...register('kaval_deivam_place')} />

        <Input label="Native Place" required {...register('native_place', { required: 'Required' })} />
        <Input label="Religion" required {...register('religion', { required: 'Required' })} />
        <Input label="District" required {...register('district', { required: 'Required' })} error={errors.district?.message} />
        <Input label="Country" required {...register('country', { required: 'Required' })} error={errors.country?.message} />
      </div>

      <div className="flex justify-between pt-2">
        <button type="button" onClick={onBack} className="btn-outline">Back</button>
        <button type="submit" disabled={isSubmitting} className="btn-primary">Save &amp; Continue</button>
      </div>
    </form>
  )
}