import { useForm, Controller } from 'react-hook-form'
import Input from '../ui/Input'
import Select from '../ui/Select'
import Textarea from '../ui/Textarea'
import { QUALIFICATION_LEVELS, PROFESSIONAL_CATEGORIES, VISION_REASONS } from '../../lib/constants'

function toOptions(list) {
  return list.map((v) => ({ value: v, label: v }))
}

export default function Step4Education({ profile, onSubmit, onBack }) {
  const { register, handleSubmit, control, watch, formState: { isSubmitting } } = useForm({
    defaultValues: {
      qualification_level: profile.qualification_level || '',
      institution_name: profile.institution_name || '',
      professional_category: profile.professional_category || '',
      occupation: profile.occupation || '',
      business_name: profile.business_name || '',
      business_nature: profile.business_nature || '',
      hospital_name: profile.hospital_name || '',
      bank_name: profile.bank_name || '',
      bank_position: profile.bank_position || '',
      professional_details: profile.professional_details || '',
      vision_reasons: profile.vision_reasons || [],
    },
  })

  const category = watch('professional_category')

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div>
        <h2 className="font-display text-lg font-semibold text-navy-900">Education &amp; Occupation</h2>
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <Select label="Qualification Level" options={toOptions(QUALIFICATION_LEVELS)} placeholder="Select qualification" {...register('qualification_level')} />
        <Input label="School / College / University Name" {...register('institution_name')} />
      </div>

      <div>
        <h3 className="font-display text-base font-semibold text-navy-900">Professional Details</h3>
        <div className="mt-3 grid gap-5 sm:grid-cols-2">
          <Select label="Category" options={PROFESSIONAL_CATEGORIES} placeholder="Select category" {...register('professional_category')} />
          <Input label="Occupation / Job Title" placeholder="e.g. Software Engineer, Farmer" {...register('occupation')} />

          {category === 'business' && (
            <>
              <Input label="Business Name" {...register('business_name')} />
              <Input label="Nature of Business" {...register('business_nature')} />
            </>
          )}
          {category === 'doctor' && <Input label="Hospital Name" {...register('hospital_name')} />}
          {category === 'banker' && (
            <>
              <Input label="Bank Name" {...register('bank_name')} />
              <Input label="Position" {...register('bank_position')} />
            </>
          )}
        </div>
        <Textarea
          label="Other Professional Details"
          placeholder="Certifications, professional memberships, notable achievements."
          className="mt-4"
          {...register('professional_details')}
        />
      </div>

      <div>
        <h3 className="font-display text-base font-semibold text-navy-900">Your Vision to Join</h3>
        <p className="mt-1 text-sm text-slate-500">Select all reasons that apply to you.</p>
        <Controller
          control={control}
          name="vision_reasons"
          render={({ field }) => (
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              {VISION_REASONS.map((reason) => {
                const checked = field.value?.includes(reason)
                return (
                  <label key={reason} className="flex items-center gap-2 rounded-sm2 border border-slate-200 px-3 py-2 text-sm text-slate-600">
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={(e) => {
                        const next = e.target.checked
                          ? [...(field.value || []), reason]
                          : (field.value || []).filter((r) => r !== reason)
                        field.onChange(next)
                      }}
                    />
                    {reason}
                  </label>
                )
              })}
            </div>
          )}
        />
      </div>

      <div className="flex justify-between pt-2">
        <button type="button" onClick={onBack} className="btn-outline">Back</button>
        <button type="submit" disabled={isSubmitting} className="btn-primary">Save &amp; Continue</button>
      </div>
    </form>
  )
}