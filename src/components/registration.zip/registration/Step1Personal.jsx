import { useForm, Controller } from 'react-hook-form'
import { Crown, UserPlus } from 'lucide-react'
import Input from '../ui/Input'
import Select from '../ui/Select'
import Textarea from '../ui/Textarea'
import { GENDERS,BLOOD_GROUPS,  REGISTRATION_TYPES, BIRTH_COUNTRIES } from '../../lib/constants'

function toOptions(list) {
  return list.map((v) => ({ value: v, label: v }))
}

export default function Step1Personal({ profile, onSubmit }) {
  const { register, handleSubmit, control, watch, formState: { errors, isSubmitting } } = useForm({
    defaultValues: {
      registration_type: profile.registration_type || 'individual_member',
      full_name: profile.full_name || '',
      gender: profile.gender || '',
      dob: profile.dob || '',
      birth_country: profile.birth_country || 'Sri Lanka',
      birth_place: profile.birth_place || '',
      blood_group: profile.blood_group || '',
      mobile: profile.mobile || '',
      whatsapp: profile.whatsapp || '',
      facebook_url: profile.facebook_url || '',
      email: profile.email || '',
      address: profile.address || '',
      village: profile.village || '',
    },
  })

  const registrationType = watch('registration_type')

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div>
        <h2 className="font-display text-lg font-semibold text-navy-900">Registration Type</h2>
        <p className="mt-1 text-sm text-slate-500">Choose how you're joining the registry.</p>
        <Controller
          control={control}
          name="registration_type"
          render={({ field }) => (
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              {REGISTRATION_TYPES.map((opt) => {
                const Icon = opt.value === 'family_head' ? Crown : UserPlus
                const active = field.value === opt.value
                return (
                  <button
                    type="button"
                    key={opt.value}
                    onClick={() => field.onChange(opt.value)}
                    className={`flex items-start gap-3 rounded-sm2 border p-4 text-left transition-colors ${
                      active ? 'border-navy-600 bg-navy-50' : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <Icon size={20} className={active ? 'text-navy-700' : 'text-slate-400'} />
                    <span>
                      <span className="block text-sm font-semibold text-navy-900">{opt.label}</span>
                      <span className="mt-0.5 block text-xs text-slate-500">{opt.description}</span>
                    </span>
                  </button>
                )
              })}
            </div>
          )}
        />
        {registrationType === 'individual_member' && (
          <p className="mt-2 rounded-sm2 bg-gold-50 px-3 py-2 text-xs text-gold-700">
            You'll be asked for your family's existing Family ID in Step 3 — Family Details.
          </p>
        )}
      </div>

      <div>
        <h2 className="font-display text-lg font-semibold text-navy-900">Personal Details</h2>
        <div className="mt-4 grid gap-5 sm:grid-cols-2">
          <Input label="Full Name" required {...register('full_name', { required: 'Full name is required' })} error={errors.full_name?.message} />
          <Select label="Gender" required options={GENDERS} placeholder="Select gender" {...register('gender', { required: 'Required' })} error={errors.gender?.message} />
          <Input type="date" label="Date of Birth" required {...register('dob', { required: 'Required' })} error={errors.dob?.message} />
          <Select label="Blood Group" options={BLOOD_GROUPS.map((b) => ({ value: b, label: b }))} placeholder="Select blood group" {...register('blood_group')} />
          <Input label="Birth Country" placeholder="Enter your birth country" {...register('birth_country')} />
          <Input label="Birth Place / City" {...register('birth_place')} />
          <Input label="Mobile Number" required {...register('mobile', { required: 'Required' })} error={errors.mobile?.message} />
          <Input type="email" label="Email Address" required {...register('email', { required: 'Required' })} error={errors.email?.message} />
          <Input label="WhatsApp Number" {...register('whatsapp')} />
          <Input label="Facebook Profile Link" {...register('facebook_url')} />
          <Input label="Village / Town" required className="sm:col-span-2" {...register('village', { required: 'Required' })} />
        </div>
        <Textarea label="Full Address" required className="mt-5" {...register('address', { required: 'Required' })} error={errors.address?.message} />
      </div>

      <div className="flex justify-end pt-2">
        <button type="submit" disabled={isSubmitting} className="btn-primary w-full sm:w-auto">
          Save &amp; Continue
        </button>
      </div>
    </form>
  )
}