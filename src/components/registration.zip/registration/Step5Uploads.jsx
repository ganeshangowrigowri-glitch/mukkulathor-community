import { useState } from 'react'
import toast from 'react-hot-toast'
import FileUpload from '../ui/FileUpload'
import { uploadProfilePhoto } from '../../services/profileService'
import { uploadFamilyPhoto } from '../../services/familyService'
import { uploadDocument } from '../../services/documentService'

export default function Step5Uploads({ profileId, profile, onDone, onBack }) {
  const [profilePhoto, setProfilePhoto] = useState(null)
  const [familyPhotos, setFamilyPhotos] = useState([])
  const [idProof, setIdProof] = useState(null)
  const [addressProof, setAddressProof] = useState(null)
  const [supportingDocs, setSupportingDocs] = useState([])
  const [saving, setSaving] = useState(false)

  async function handleContinue() {
    setSaving(true)
    try {
      if (profilePhoto) await uploadProfilePhoto(profileId, profilePhoto)
      for (const file of familyPhotos) {
        await uploadFamilyPhoto(profileId, file)
      }
      if (idProof) await uploadDocument(profileId, idProof, 'id_proof')
      if (addressProof) await uploadDocument(profileId, addressProof, 'address_proof')
      for (const file of supportingDocs) {
        await uploadDocument(profileId, file, 'supporting_document')
      }
      onDone()
    } catch (err) {
      toast.error(err.message || 'Upload failed')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display text-lg font-semibold text-navy-900">Upload Documents &amp; Photos</h2>
        <p className="mt-1 text-sm text-slate-500">
          These help referees and the admin verify your identity and family history. Already uploaded a profile
          photo? You may skip and continue.
        </p>
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <FileUpload label="Profile Photo" accept="image/*" onFiles={setProfilePhoto} hint="JPG or PNG, up to 5MB" />
        <FileUpload label="Family Photo(s)" accept="image/*" multiple onFiles={setFamilyPhotos} hint="You can select multiple photos" />
        <FileUpload label="ID Proof" accept="image/*,application/pdf" onFiles={setIdProof} hint="Aadhaar / Voter ID / Passport" />
        <FileUpload label="Address Proof" accept="image/*,application/pdf" onFiles={setAddressProof} hint="Utility bill / ration card" />
        <FileUpload
          label="Supporting Document(s)"
          accept="image/*,application/pdf"
          multiple
          onFiles={setSupportingDocs}
          hint="Any other document supporting your application"
        />
      </div>

      {profile.profile_photo_url && (
        <div className="flex items-center gap-3 rounded-sm2 bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
          A profile photo is already on file. Uploading a new one will replace it.
        </div>
      )}

      <div className="flex justify-between pt-2">
        <button type="button" onClick={onBack} className="btn-outline">Back</button>
        <button type="button" onClick={handleContinue} disabled={saving} className="btn-primary">
          {saving ? 'Uploading…' : 'Save & Continue'}
        </button>
      </div>
    </div>
  )
}
