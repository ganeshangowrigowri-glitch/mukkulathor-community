import { useEffect, useState, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'
import { useAuth } from '../../context/AuthContext'
import { getProfile, updateProfile } from '../../services/profileService'
import { listFamilyMembers, syncFamilyMembers, syncFamilyTree } from '../../services/familyService'
import StepIndicator from '../ui/StepIndicator'
import PageLoader from '../ui/PageLoader'
import Step1Personal from './Step1Personal'
import Step2Community from './Step2Community'
import Step3Family from './Step3Family'
import Step4Education from './Step4Education'
import Step5Uploads from './Step5Uploads'
import Step6Referees from './Step6Referees'

const STEPS = ['Personal', 'Community', 'Family', 'Education', 'Uploads', 'Referees']

export default function RegistrationWizard() {
  const { profile, refreshProfile } = useAuth()
  const [current, setCurrent] = useState(1)
  const [localProfile, setLocalProfile] = useState(profile)
  const [familyMembers, setFamilyMembers] = useState([])
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()

  const load = useCallback(async () => {
    if (!profile?.id) return
    setLoading(true)
    const [p, fm] = await Promise.all([getProfile(profile.id), listFamilyMembers(profile.id)])
    setLocalProfile(p)
    setFamilyMembers(fm)
    setLoading(false)
  }, [profile?.id])

  useEffect(() => {
    load()
  }, [load])

  useEffect(() => {
    // If registration has already moved past 'draft', the wizard is no
    // longer editable — send the applicant to their status page instead.
    if (localProfile && localProfile.registration_status !== 'draft') {
      navigate('/member/status', { replace: true })
    }
  }, [localProfile, navigate])

  async function persist(updates) {
    const updated = await updateProfile(profile.id, updates)
    setLocalProfile(updated)
    await refreshProfile()
    return updated
  }

  function goNext() {
    setCurrent((c) => Math.min(c + 1, STEPS.length))
  }
  function goBack() {
    setCurrent((c) => Math.max(c - 1, 1))
  }

  if (loading || !localProfile) return <PageLoader label="Loading your registration…" />

  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="font-display text-2xl font-semibold text-navy-900">Membership Registration</h1>
      <p className="mt-1 text-sm text-slate-500">
        Complete all six steps to submit your application for referee verification.
      </p>

      <StepIndicator steps={STEPS} current={current} />

      <div className="card p-6 sm:p-8">
        {current === 1 && (
          <Step1Personal
            profile={localProfile}
            onSubmit={async (data) => {
              await persist(data)
              toast.success('Personal details saved')
              goNext()
            }}
          />
        )}
        {current === 2 && (
          <Step2Community
            profile={localProfile}
            onBack={goBack}
            onSubmit={async (data) => {
              await persist(data)
              toast.success('Community details saved')
              goNext()
            }}
          />
        )}
        {current === 3 && (
          <Step3Family
            profile={localProfile}
            familyMembers={familyMembers}
            onBack={goBack}
            onSubmit={async ({ profileUpdates, members }) => {
              await persist(profileUpdates)
              const saved = await syncFamilyMembers(profile.id, members)
              await syncFamilyTree(profile.id, saved)
              setFamilyMembers(saved)
              toast.success('Family details saved')
              goNext()
            }}
          />
        )}
        {current === 4 && (
          <Step4Education
            profile={localProfile}
            onBack={goBack}
            onSubmit={async (data) => {
              await persist(data)
              toast.success('Education & occupation saved')
              goNext()
            }}
          />
        )}
        {current === 5 && (
          <Step5Uploads
            profileId={profile.id}
            profile={localProfile}
            onBack={goBack}
            onDone={() => {
              toast.success('Uploads saved')
              goNext()
            }}
          />
        )}
        {current === 6 && (
          <Step6Referees
            onBack={goBack}
            onSubmitted={() => {
              toast.success('Registration submitted for referee verification')
              navigate('/member/status')
            }}
          />
        )}
      </div>
    </div>
  )
}
