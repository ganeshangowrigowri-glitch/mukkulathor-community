import { useForm, useFieldArray, Controller, useWatch } from 'react-hook-form'
import { Plus, Trash2 } from 'lucide-react'
import Input from '../ui/Input'
import Select from '../ui/Select'
import { RELATION_TYPES, GENDERS, MARRIAGE_STATUSES, BIRTH_COUNTRIES, BRANCHES, SUB_CLANS_BY_BRANCH, TITLES_BY_BRANCH, GOTHRAMS } from '../../lib/constants'

function toOptions(list) {
  return list.map((v) => ({ value: v, label: v }))
}

const BLANK_SPOUSE_LINEAGE = {
  great_grandfather_name: '', great_grandfather_birth_country: 'Sri Lanka', great_grandfather_birth_place: '',
  grandfather_name: '', grandfather_birth_country: 'Sri Lanka', grandfather_birth_place: '',
  branch: '', sub_group: '', title: '',
  kula_deivam: '', kula_deivam_place: '',
  kaval_deivam: '', kaval_deivam_place: '',
  gothram: '',
  father_name: '', father_birth_country: 'Sri Lanka', father_birth_place: '',
  spouse_birth_country: 'Sri Lanka', spouse_birth_place: '',
}

function SpouseLineageFields({ control, register }) {
  const branch = useWatch({ control, name: 'spouse_lineage.branch' })
  const subClanOptions = branch ? toOptions(SUB_CLANS_BY_BRANCH[branch] || []) : []
  const titleOptions = branch ? toOptions(TITLES_BY_BRANCH[branch] || []) : []

  return (
    <div className="mt-4 space-y-4 rounded-sm2 border border-gold-200 bg-gold-50/40 p-4">
      <h4 className="font-display text-sm font-semibold text-navy-900">Spouse's Lineage</h4>

      <div className="grid gap-4 sm:grid-cols-3">
        <Input label="Great-Grandfather's Name" {...register('spouse_lineage.great_grandfather_name')} />
        <Input label="Birth Country" placeholder="e.g., Sri Lanka, India, Malaysia" {...register('spouse_lineage.great_grandfather_birth_country')} />
        <Input label="Birth Place / City" {...register('spouse_lineage.great_grandfather_birth_place')} />

        <Input label="Grandfather's Name" {...register('spouse_lineage.grandfather_name')} />
        <Input label="Birth Country" placeholder="e.g., Sri Lanka, India, Malaysia" {...register('spouse_lineage.grandfather_birth_country')} />
        <Input label="Birth Place / City" {...register('spouse_lineage.grandfather_birth_place')} />

        <Select label="Branch (Kilai)" options={BRANCHES} placeholder="Select branch" {...register('spouse_lineage.branch')} />
        <Select label="Sub-Clan / Pattam" options={subClanOptions} placeholder={branch ? 'Select sub-clan' : 'Select a branch first'} disabled={!branch} {...register('spouse_lineage.sub_group')} />
        <Select label="Title" options={titleOptions} placeholder={branch ? 'Select title' : 'Select a branch first'} disabled={!branch} {...register('spouse_lineage.title')} />

        <Input label="Kula Deivam" {...register('spouse_lineage.kula_deivam')} />
        <Input label="Kula Deivam Place" {...register('spouse_lineage.kula_deivam_place')} />
        <Input label="Kaval Deivam" {...register('spouse_lineage.kaval_deivam')} />
        <Input label="Kaval Deivam Place" {...register('spouse_lineage.kaval_deivam_place')} />

        <Select label="Gothram" options={toOptions(GOTHRAMS)} placeholder="Select gothram" {...register('spouse_lineage.gothram')} />
        <div />
        <div />

        <Input label="Father's Name" {...register('spouse_lineage.father_name')} />
        <Input label="Birth Country" placeholder="e.g., Sri Lanka, India, Malaysia" {...register('spouse_lineage.father_birth_country')} />
        <Input label="Birth Place / City" {...register('spouse_lineage.father_birth_place')} />

        <Input label="Spouse's Birth Country" placeholder="e.g., Sri Lanka, India, Malaysia" {...register('spouse_lineage.spouse_birth_country')} />
        <Input label="Spouse's Birth Place / City" {...register('spouse_lineage.spouse_birth_place')} />
      </div>
    </div>
  )
}

export default function Step3Family({ profile, familyMembers, onSubmit, onBack }) {
  const { register, control, handleSubmit, watch, formState: { errors, isSubmitting } } = useForm({
    defaultValues: {
      marriage_status: profile.marriage_status || 'single',
      marriage_date: profile.marriage_date || '',
      family_id: profile.family_id || '',
      spouse_is_mukkulathor: profile.spouse_is_mukkulathor === true ? 'yes' : profile.spouse_is_mukkulathor === false ? 'no' : '',
      spouse_lineage: { ...BLANK_SPOUSE_LINEAGE, ...(profile.spouse_lineage || {}) },
      members:
        familyMembers.length > 0
          ?familyMembers.map((m) => ({ ...m }))
          : [
              { relation_type: 'great_grandfather', full_name: '', gender: 'male', dob: '', occupation: '', birth_country: 'Sri Lanka', birth_place: '', title: '', branch: '', sub_clan: '', kula_deivam: '', kaval_deivam: '',},
              { relation_type: 'grandfather', full_name: '', gender: 'male', dob: '', occupation: '', birth_country: 'Sri Lanka', birth_place: '', title: '', branch: '', sub_clan: '', kula_deivam: '', kaval_deivam: '', kula_deivam_country: '', kaval_deivam_country: '' },
              { relation_type: 'father', full_name: '', gender: 'male', dob: '', occupation: '', birth_country: 'Sri Lanka', birth_place: '', title: '', branch: '', sub_clan: '', kula_deivam: '', kaval_deivam: '', kula_deivam_country: '', kaval_deivam_country: '' },
              { relation_type: 'mother', full_name: '', gender: 'female', dob: '', occupation: '', birth_country: 'Sri Lanka', birth_place: '', title: '', branch: '', sub_clan: '', kula_deivam: '', kaval_deivam: '',},
            ],
    },
  })

  const { fields, append, remove } = useFieldArray({ control, name: 'members' })
  const marriageStatus = watch('marriage_status')
  const spouseIsMukkulathor = watch('spouse_is_mukkulathor')
  const isIndividualMember = profile.registration_type === 'individual_member'

  function submit(data) {
    const { marriage_status, marriage_date, family_id, members, spouse_is_mukkulathor, spouse_lineage } = data
    onSubmit({
      profileUpdates: {
        marriage_status,
        marriage_date: marriage_date || null,
        family_id: family_id || null,
        spouse_is_mukkulathor: marriage_status === 'married' ? spouse_is_mukkulathor === 'yes' : null,
        spouse_lineage: marriage_status === 'married' && spouse_is_mukkulathor === 'yes' ? spouse_lineage : null,
      },
      members: members.map((m) => ({ ...m, dob: m.dob || null })),
    })
  }

  return (
    <form onSubmit={handleSubmit(submit)} className="space-y-6">
      <div>
        <h2 className="font-display text-lg font-semibold text-navy-900">Family Details</h2>
        <p className="mt-1 text-sm text-slate-500">
          Record your lineage — great grandfather, grandfather, father, mother, family head, spouse and children.
          This builds your Family Tree automatically.
        </p>
      </div>

      <div className="grid gap-5 sm:grid-cols-3">
        <Select label="Marriage Status" options={MARRIAGE_STATUSES} {...register('marriage_status')} />
        {marriageStatus === 'married' && <Input type="date" label="Marriage Date" {...register('marriage_date')} />}
        <Input
          label="Family ID"
          required={isIndividualMember}
          placeholder="e.g. MTC-KAL-000123"
          hint={
            isIndividualMember
              ? "Required — enter your Family Head's registered Family ID to link your record."
              : 'Optional — leave blank and one will be generated for your family upon approval.'
          }
          error={errors.family_id?.message}
          {...register('family_id', { required: isIndividualMember ? "Required for individual member registration" : false })}
        />
      </div>

      {marriageStatus === 'married' && (
        <div className="rounded-sm2 border border-slate-200 p-4">
          <p className="mb-2 text-sm font-medium text-navy-900">Is your spouse also Mukkulathor?</p>
          <div className="flex gap-4">
            <label className="flex items-center gap-2 text-sm text-slate-600">
              <input type="radio" value="yes" {...register('spouse_is_mukkulathor')} /> Yes
            </label>
            <label className="flex items-center gap-2 text-sm text-slate-600">
              <input type="radio" value="no" {...register('spouse_is_mukkulathor')} /> No
            </label>
          </div>
          {spouseIsMukkulathor === 'yes' && <SpouseLineageFields control={control} register={register} />}
        </div>
      )}

      <div className="space-y-3">
        {fields.map((field, idx) => {
          const selectedBranch = watch(`members.${idx}.branch`)
          const subClanOptions = selectedBranch ? toOptions(SUB_CLANS_BY_BRANCH[selectedBranch] || []) : []
          const titleOptions = selectedBranch ? toOptions(TITLES_BY_BRANCH[selectedBranch] || []) : []

          return (
            <div key={field.id} className="space-y-3 rounded-sm2 border border-slate-200 p-4">
              {/* Row 1: Relation, Full Name, Gender, Date of Birth */}
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-12 sm:items-end">
                <Select
                  className="sm:col-span-2"
                  label="Relation"
                  options={RELATION_TYPES}
                  {...register(`members.${idx}.relation_type`, { required: true })}
                />
                <Input className="sm:col-span-4" label="Full Name" {...register(`members.${idx}.full_name`, { required: true })} />
                <Select className="sm:col-span-2" label="Gender" options={GENDERS} {...register(`members.${idx}.gender`)} />
                <Input className="sm:col-span-3" type="date" label="Date of Birth" {...register(`members.${idx}.dob`)} />
                <button
                  type="button"
                  onClick={() => remove(idx)}
                  className="flex h-10 items-center justify-center rounded-sm2 text-red-400 hover:bg-red-50 hover:text-red-600 sm:col-span-1"
                  aria-label="Remove family member"
                >
                  <Trash2 size={17} />
                </button>
              </div>

              {/* Row 2: Birth Country, Birth Place / City, Occupation */}
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-12">
                <Input className="sm:col-span-4" label="Birth Country" placeholder="e.g., Sri Lanka, India, Malaysia" {...register(`members.${idx}.birth_country`)} />
                <Input className="sm:col-span-4" label="Birth Place / City" {...register(`members.${idx}.birth_place`)} />
                <Input className="sm:col-span-4" label="Occupation" {...register(`members.${idx}.occupation`)} />
              </div>

              {/* Row 3: Branch (Kilai), Sub-Clan / Pattam, Title */}
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-12">
                <Select
                  className="sm:col-span-4"
                  label="Branch (Kilai)"
                  options={BRANCHES}
                  placeholder="Select branch"
                  {...register(`members.${idx}.branch`)}
                />
                <Select
                  className="sm:col-span-4"
                  label="Sub-Clan / Pattam"
                  options={subClanOptions}
                  placeholder={selectedBranch ? 'Select sub-clan' : 'Select a branch first'}
                  disabled={!selectedBranch}
                  {...register(`members.${idx}.sub_clan`)}
                />
                <Select
                  className="sm:col-span-4"
                  label="Title"
                  options={titleOptions}
                  placeholder={selectedBranch ? 'Select title' : 'Select a branch first'}
                  disabled={!selectedBranch}
                  {...register(`members.${idx}.title`)}
                />
              </div>

              {/* Row 4: Kula Deivam, Kula Deivam Place */}
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-12">
                <Input
                  className="sm:col-span-6"
                  label="Kula Deivam"
                  placeholder="Deity name"
                  {...register(`members.${idx}.kula_deivam`)}
                />
                <Input
                  className="sm:col-span-6"
                  label="Kula Deivam Place"
                  placeholder="Temple place"
                  {...register(`members.${idx}.kula_deivam_place`)}
                />
              </div>

              {/* Row 5: Kaval Deivam, Kaval Deivam Place */}
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-12">
                <Input
                  className="sm:col-span-6"
                  label="Kaval Deivam"
                  placeholder="Deity name"
                  {...register(`members.${idx}.kaval_deivam`)}
                />
                <Input
                  className="sm:col-span-6"
                  label="Kaval Deivam Place"
                  placeholder="Temple place"
                  {...register(`members.${idx}.kaval_deivam_place`)}
                />
              </div>
            </div>
          )
        })}

        <button
          type="button"
          onClick={() => append({ relation_type: 'child', full_name: '', gender: 'male', dob: '', occupation: '', birth_country: 'Sri Lanka', birth_place: '', title: '', branch: '', sub_clan: '', kula_deivam: '', kaval_deivam: '', })}
          className="btn-outline w-full justify-center sm:w-auto"
        >
          <Plus size={16} /> Add Family Member
        </button>
      </div>

      <div className="flex justify-between pt-2">
        <button type="button" onClick={onBack} className="btn-outline">Back</button>
        <button type="submit" disabled={isSubmitting} className="btn-primary">Save &amp; Continue</button>
      </div>
    </form>
  )
}
