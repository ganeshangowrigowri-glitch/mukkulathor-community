import { useEffect, useState } from 'react'
import toast from 'react-hot-toast'
import { UserCheck } from 'lucide-react'
import { listActiveReferees, submitRegistration } from '../../services/refereeService'
import PageLoader from '../ui/PageLoader'
import EmptyState from '../ui/EmptyState'

export default function Step6Referees({ onSubmitted, onBack }) {
  const [referees, setReferees] = useState([])
  const [selected, setSelected] = useState([])
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    listActiveReferees().then((data) => {
      setReferees(data)
      setLoading(false)
    })
  }, [])

  function toggle(id) {
    setSelected((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]))
  }

  async function handleSubmit() {
    if (selected.length === 0) {
      toast.error('Please select at least one referee')
      return
    }
    setSubmitting(true)
    try {
      await submitRegistration(selected)
      onSubmitted()
    } catch (err) {
      toast.error(err.message || 'Could not submit registration')
    } finally {
      setSubmitting(false)
    }
  }

  if (loading) return <PageLoader label="Loading available referees…" />

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display text-lg font-semibold text-navy-900">Choose Referees</h2>
        <p className="mt-1 text-sm text-slate-500">
          Select one or more verified members to recommend your application. They will receive an email asking
          them to approve or reject your request.
        </p>
      </div>

      {referees.length === 0 ? (
        <EmptyState
          icon={UserCheck}
          title="No referees available yet"
          description="The community office hasn't designated any referees. Please contact the admin or try again later."
        />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {referees.map((ref) => {
            const isSelected = selected.includes(ref.id)
            return (
              <label
                key={ref.id}
                className={`flex cursor-pointer items-start gap-3 rounded-sm2 border p-4 transition-colors ${
                  isSelected ? 'border-navy-600 bg-navy-50' : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <input type="checkbox" className="mt-1 h-4 w-4 accent-navy-700" checked={isSelected} onChange={() => toggle(ref.id)} />
                <div>
                  <p className="text-sm font-semibold text-navy-900">{ref.profiles?.full_name}</p>
                  <p className="text-xs text-slate-500">
                    {ref.designation || 'Referee'} {ref.region ? `· ${ref.region}` : ''}
                  </p>
                  <p className="text-xs capitalize text-slate-400">{ref.profiles?.branch}</p>
                </div>
              </label>
            )
          })}
        </div>
      )}

      <div className="flex justify-between pt-2">
        <button type="button" onClick={onBack} className="btn-outline">Back</button>
        <button type="button" onClick={handleSubmit} disabled={submitting} className="btn-gold">
          {submitting ? 'Submitting…' : 'Submit Registration'}
        </button>
      </div>
    </div>
  )
}
